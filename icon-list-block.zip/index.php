<?php

/**
 * Plugin Name: Icon List Block
 * Description: Show your icon list in web.
 * Version: 1.0.9
 * Author: bPlugins
 * Author URI: https://bplugins.com
 * License: GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.txt
 * Text Domain: icon-list
 */

// ABS PATH
if (!defined('ABSPATH')) {
    exit;
}

// Constant
define('ILB_VERSION', isset($_SERVER['HTTP_HOST']) && 'localhost' === $_SERVER['HTTP_HOST'] ? time() : '1.0.9');
define('ILB_DIR_URL', plugin_dir_url(__FILE__));
define('ILB_DIR_PATH', plugin_dir_path(__FILE__));

// require_once ILB_DIR_PATH . 'src/render.php';



if (!class_exists('ILBPlugin')) {
    class ILBPlugin
    {
        public function __construct()
        {
            add_action('enqueue_block_assets', [$this, 'enqueueBlockAssets']);
            add_action('init', [$this, 'onInit']);
        }
        function enqueueBlockAssets()
        {
            wp_register_style('fontAwesome', ILB_DIR_URL . 'assets/css/font-awesome.min.css', [], '6.4.2'); // Icon
        }

        function onInit()
        {
            register_block_type(__DIR__ . '/build');
        }
    }

    new ILBPlugin();
}
